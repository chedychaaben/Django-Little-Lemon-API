from rest_framework import permissions


class IsManager(permissions.BasePermission):
    """
    Check if user is in manager group
    """

    def has_permission(self, request, view):
        user = request.user
        is_manager = user.groups.filter(name='Manager').exists()
        return is_manager or permissions.IsAdminUser().has_permission(request, view)