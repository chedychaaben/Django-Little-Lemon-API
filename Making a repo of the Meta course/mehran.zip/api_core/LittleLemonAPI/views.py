from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from .permission import IsManager
from .models import MenuItem, Category, Cart, Order
from .serializers import MenuItemSerializer, CategorySerializer, GroupSerializer,\
    CartSerializer, OrderSerializer, CreateOrderSerializer, OrderItemSerializer,\
    UpdateOrderSerializer
from django.contrib.auth.models import Group, User
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.throttling import UserRateThrottle, AnonRateThrottle


# Create your views here.

class MenuItemList(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    http_method_names = ['get', 'post', 'put', 'delete', 
                         'head', 'options', 'patch']

    def get_permissions(self):
        if self.request.method == 'GET':
            return [IsAuthenticated()]
        elif self.request.method in ['POST', 'DELETE', 'PUT', 'PATCH']:
            return [IsAuthenticated(), IsManager()]
        else:
            return super().get_permissions()

    serializer_class = MenuItemSerializer
    def get_queryset(self):
        cat_name = self.request.query_params.get('cat')
        if cat_name:
            queryset = MenuItem.objects.filter(category__title=cat_name).all()
        else:
            queryset = MenuItem.objects.all()
       
        return queryset

class CategoryView(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    http_method_names = ['get', 'post', 'put', 'delete', 
                         'head', 'options', 'patch']

    def get_permissions(self):
        if self.request.method == 'GET':
            return [IsAuthenticated()]
        elif self.request.method in ['POST', 'DELETE', 'PUT', 'PATCH']:
            return [IsAuthenticated(), IsManager(), IsAdminUser()]
        else:
            return super().get_permissions()

    serializer_class = CategorySerializer
    queryset = Category.objects.all()


# class ManagerView(ViewSet):
#     # queryset = Group.objects.get(name='Manager').user_set.all()
#     # serializer_class = GroupSerializer

#     def list(self, request):
#         groups = Group.objects.get(name='Manager').user_set.all()
#         serializer = GroupSerializer(groups, many=True)
#         return Response(serializer.data)

#     def create(self, request):
#         serializer = GroupSerializer(data=request.data)
#         serializer.is_valid()
#         user = get_object_or_404(User, username=serializer.data['user_name'])
#         group_m = Group.objects.get(name='Manager')
#         group_m.user_set.add(user)
#         return Response(status=status.HTTP_201_CREATED)
    
#     def delete_user(self, request, user_id):
#         user = get_object_or_404(User, id=user_id)
#         group_m = Group.objects.get(name='Manager')
#         group_m.user_set.remove(user)
#         return Response(status=status.HTTP_204_NO_CONTENT)

#     def retrieve_user(self, request, user_id):
#         groups = Group.objects.get(name='Manager').user_set.filter(id=user_id).all()
#         serializer = GroupSerializer(groups, many=True)
#         return Response(serializer.data)


class ManagerViewSet(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    queryset = Group.objects.filter(name='Manager').first().user_set.all()
    serializer_class = GroupSerializer
    http_method_names = ['get', 'post', 'delete', 'head', 'options']
    permission_classes = [IsAuthenticated, IsManager]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        #print(serializer.validated_data)
        user_name = serializer.validated_data['username']
        user = get_object_or_404(User, username=user_name)
        group = Group.objects.filter(name='Manager').first()
        group.user_set.add(user)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance=instance)
        user_name = serializer.data['user_name']
        user = get_object_or_404(User, username=user_name)
        group = Group.objects.filter(name='Manager').first()
        group.user_set.remove(user)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class CrewViewSet(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    queryset = Group.objects.filter(name='Delivery').first().user_set.all()
    serializer_class = GroupSerializer
    http_method_names = ['get', 'post', 'delete', 'head', 'options']
    permission_classes = [IsAuthenticated, IsManager]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        #print(serializer.validated_data)
        user_name = serializer.validated_data['username']
        user = get_object_or_404(User, username=user_name)
        group = Group.objects.filter(name='Delivery').first()
        group.user_set.add(user)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance=instance)
        user_name = serializer.data['user_name']
        user = get_object_or_404(User, username=user_name)
        group = Group.objects.filter(name='Delivery').first()
        group.user_set.remove(user)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class CartViewSet(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    def get_queryset(self):
        user = self.request.user  # Get the current authenticated user from the request
        queryset = Cart.objects.filter(user=user)
        return queryset

    serializer_class = CartSerializer
    http_method_names = ['get', 'post', 'delete', 'head', 'options']
    permission_classes = [IsAuthenticated]


    def delete(self, request, *args, **kwargs):
        instance = Cart.objects.filter(user=self.request.user)
        print(instance)
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)


class OrdersViewSet(ModelViewSet):
    throttle_classes = [AnonRateThrottle, UserRateThrottle]
    http_method_names = ['get', 'post', 'patch', 'delete', 'head', 'options']

    def get_permissions(self):
        if self.request.method in ['PATCH', 'DELETE']:
            if self.request.user.groups.filter(name='Delivery').exists():
                return [IsAuthenticated()]
            return [IsManager()]
        return [IsAuthenticated()]
    
    def create(self, request, *args, **kwargs):
        serializer = CreateOrderSerializer(
            data=request.data,
            context={'user_id': self.request.user.id,
            'user': self.request.user.id})
        serializer.is_valid(raise_exception=True)
        order = serializer.save()
        serializer = OrderSerializer(order)
        return Response(serializer.data)

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return CreateOrderSerializer
        elif self.request.method == 'PATCH' or self.request.method == 'PUT':
            return UpdateOrderSerializer
        return OrderSerializer

    def get_queryset(self):
        user = self.request.user
        if IsManager().has_permission(self.request, self):
            return Order.objects.all()

        elif user.groups.filter(name='Delivery').exists():
            return Order.objects.filter(delivery_crew=user).all()
        
        return Order.objects.filter(user=user).all()
