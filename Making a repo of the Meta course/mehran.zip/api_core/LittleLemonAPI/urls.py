from . import views
from rest_framework.routers import SimpleRouter, DefaultRouter
from django.urls import path, include
from rest_framework.decorators import action



router = DefaultRouter()
router.register('menu-item', views.MenuItemList, basename='menu')
router.register('category', views.CategoryView)

# router_2 = SimpleRouter()
# router_2.register('users', views.ManagerView)

router2 = DefaultRouter()
router2.register('groups/manager/users', views.ManagerViewSet, basename='manager-users')
router2.register('groups/delivery-crew/users', views.CrewViewSet, basename='delivery-users')
router2.register('cart/menu-items', views.CartViewSet, basename='cart')
router2.register('orders', views.OrdersViewSet, basename='order')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(router2.urls)),
    # path('groups/manager/users/', views.ManagerView.as_view({'get': 'list', 'post': 'create'}), name='manager-users'),
    # path('groups/manager/users/<int:user_id>/', views.ManagerView.as_view({'get': 'retrieve_user', 'delete': 'delete_user'}), name='manager-user-detail'),
]