from .models import MenuItem, Category, Cart, OrderItem, Order
from rest_framework import serializers
from django.contrib.auth.models import Group, User
from django.db import transaction


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['title', 'slug']
        # extra_kwargs = {
        #     'slug': {'read_only': True},
        # }

class MenuItemSerializer(serializers.ModelSerializer):
    category = serializers.StringRelatedField()
    class Meta:
        model = MenuItem
        fields = ['id', 'title', 'price', 'featured', 'category']
        #read_only_fields = ['category_name']

class GroupSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source='username')  # Update the field name to 'username'
    user_id = serializers.IntegerField(source='id', read_only=True)
    class Meta:
        model = Group
        fields = ['user_id', 'user_name']
        # extra_kwargs = {
        #     'user_name': {'read_only': True},

class SimpleMenuItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = MenuItem
        fields = ['id', 'price']

class CartSerializer(serializers.ModelSerializer):
    title = serializers.SerializerMethodField()

    def get_title(self, request):
        return request.menuitem.title

    class Meta:
        model = Cart
        fields = ['user', 'menuitem', 'title','quantity', 'unit_price', 'price']
        extra_kwargs = {
            'user': {'read_only': True},
            'unit_price': {'read_only': True},
            'price': {'read_only': True},
            'title': {'read_only': True},
            'menuitem': {'write_only': True},
        }
    
    def save(self, **kwargs):
        user = self.context['request'].user
        menuitem = self.validated_data['menuitem']
        unit_price = self.validated_data['menuitem'].price
        print(unit_price)
        quantity = self.validated_data['quantity']
        price = quantity * unit_price
        self.instance = Cart.objects.create(user=user, unit_price=unit_price,
                                            price=price,
                                            **self.validated_data)
        return self.instance

class OrderItemSerializer(serializers.ModelSerializer):
    # product = CartSerializer()

    class Meta:
        model = OrderItem
        fields = ['order', 'menuitem', 'quantity', 'unit_price', 'price']
        extra_kwargs = {
            'order': {'write_only': True},
        }

class UpdateOrderSerializer(serializers.ModelSerializer):
    delivery_crew = serializers.CharField()

    class Meta:
        model = Order
        fields = ['delivery_crew', 'status']
    def get_fields(self):
        fields = super().get_fields()
        if self.context['request'].user in Group.objects.filter(name='Delivery').first().user_set.all():
            fields.pop('delivery_crew')
        
        #print(fields)
        #fields = ['delivery_crew', 'status']

        return fields

    def update(self, instance, validated_data):
        if 'delivery_crew' in validated_data:
            username = validated_data.pop('delivery_crew')
            try:
                user = User.objects.get(username=username)
            except User.DoesNotExist:
                raise serializers.ValidationError("Invalid username for delivery crew.")
            instance.delivery_crew = user

        for key, value in validated_data.items():
            setattr(instance, key, value)

        instance.save()
        return instance


class OrderSerializer(serializers.ModelSerializer):
    user_name = serializers.SerializerMethodField()
    order_items = OrderItemSerializer(many=True, source='orderitem_set', read_only=True)

    class Meta:
        model = Order
        fields = ['id', 'user_name', 'delivery_crew', 'status', 'total', 'date', 'order_items']
        read_only_fields = ['user_name', 'delivery_crew', 'status', 'total', 'date', 'order_items']

    def get_user_name(self, obj):
        user = obj.user
        return user.username

class CreateOrderSerializer(serializers.Serializer):
    def save(self, **kwargs):
        with transaction.atomic():
            print(self.context)
            user = User.objects.get(id=self.context['user'])
            if not Cart.objects.filter(user=user).exists():
                raise serializers.ValidationError(
                    'No cart with the given ID was found.')
            if Cart.objects.filter(user=user).count() == 0:
                raise serializers.ValidationError('The cart is empty.')

            cart_items = Cart.objects \
                .select_related('menuitem') \
                .filter(user=user)
            total = sum([item.price for item in cart_items])
            order = Order.objects.create(user=user, status=0, total=total)
            order_items = [
                OrderItem(
                    order=order,
                    menuitem=item.menuitem,
                    unit_price=item.unit_price,
                    quantity=item.quantity,
                    price=item.price
                ) for item in cart_items
            ]
            OrderItem.objects.bulk_create(order_items)
            Cart.objects.filter(user=user).delete()
            return order
